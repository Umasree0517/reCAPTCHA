<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = htmlspecialchars($_POST["username"]);
    $password = htmlspecialchars($_POST["password"]);
    $recaptchaResponse = $_POST['g-recaptcha-response'];

    // ✅ TEST SECRET KEY
    $secret = "6LeIxAcTAAAAAGG-vFI1TnRWxMZNFuojJ4WifJWe";

    $response = file_get_contents(
        "https://www.google.com/recaptcha/api/siteverify?secret=$secret&response=$recaptchaResponse"
    );
    $responseKeys = json_decode($response, true);

    if ($responseKeys["success"]) {
        echo "<h2>✅ CAPTCHA Verified! Welcome, $username</h2>";
    } else {
        echo "<h2>❌ CAPTCHA verification failed. Try again.</h2>";
    }
}
?>
